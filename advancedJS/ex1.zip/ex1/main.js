
var check = document.querySelector("input");

check.addEventListener("click", function (e) {
e.preventDefault();
});